import { ElementPlusSize } from './elementPlus'
export interface ConfigGlobalTypes {
  size?: ElementPlusSize
}
