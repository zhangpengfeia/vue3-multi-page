export type LayoutType = 'classic' | 'topLeft' | 'top' | 'cutMenu'
