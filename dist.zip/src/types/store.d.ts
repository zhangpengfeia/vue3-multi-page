export interface UserInfo {
  userId: string | number
  username: string
  roles: Array
}
