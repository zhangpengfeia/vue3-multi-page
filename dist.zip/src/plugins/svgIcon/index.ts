import 'virtual:svg-icons-register'

// import '@purge-icons/generated'
// import "@purge-icons/generated"; //pnpm 方式
import '@iconify/iconify/dist/iconify' // npm方式
