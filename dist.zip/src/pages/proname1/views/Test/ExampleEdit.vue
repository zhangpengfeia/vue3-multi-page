<script setup lang="ts">
import Write from './components/Write.vue'
import { ContentDetailWrap } from '@/components/ContentDetailWrap'
import { ref, unref } from 'vue'
import { ElButton } from 'element-plus'
import { useRouter, useRoute } from 'vue-router'
// import { saveTableApi, getTableDetApi } from '@/api/table'
import { useEmitt } from '@/hooks/web/useEmitt'

const { emitter } = useEmitt()

const { push } = useRouter()

const { query } = useRoute()

const currentRow = ref<Nullable<any>>(null)

const getTableDet = async () => {
  // const res = await getTableDetApi(query.id as string)
  // if (res) {
  //   currentRow.value = res.data
  // }
}

getTableDet()

const writeRef = ref<ComponentRef<typeof Write>>()

const loading = ref(false)

const save = async () => {
  const write = unref(writeRef)
  const validate = await write?.elFormRef?.validate()?.catch(() => {})
  if (validate) {
    loading.value = true
    // const data = (await write?.getFormData()) as TableData
    // const res = await saveTableApi(data)
    //   .catch(() => {})
    //   .finally(() => {
    //     loading.value = false
    //   })
    // if (res) {
    emitter.emit('getList', 'edit')
    push('/test/index')
    // }
  }
}
</script>

<template>
  <ContentDetailWrap title="编辑" @back="push('/test/index')">
    <Write ref="writeRef" :current-row="currentRow" />

    <template #right>
      <ElButton type="primary" :loading="loading" @click="save"> 保存 </ElButton>
    </template>
  </ContentDetailWrap>
</template>
