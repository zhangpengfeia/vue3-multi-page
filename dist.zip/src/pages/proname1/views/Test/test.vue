<script setup lang="ts">
import { ContentWrap } from '@/components/ContentWrap'
import { Table } from '@/components/Table'
import { loginApi } from '../../interface/login'
import { TableData } from '../../interface/login/types'
import { h, reactive, unref } from 'vue'
import { ElTag, ElButton } from 'element-plus'
import { useTable } from '@/hooks/web/useTable'
import { TableColumn, TableSlotDefault } from '@/types/table'

const { register, tableObject, methods, elTableRef } = useTable<TableData>({
  getListApi: loginApi,
  response: {
    list: 'list',
    total: 'total'
  }
})

const { getList } = methods

getList()

const columns = reactive<TableColumn[]>([
  // {
  //   field: 'index',
  //   label: '序号',
  //   type: 'index'
  // },
  {
    field: 'title',
    label: '标题'
  },
  {
    field: 'author',
    label: '作者'
  },
  {
    field: 'display_time',
    label: '创建时间'
  },
  {
    field: 'importance',
    label: '状态',
    formatter: (_: Recordable, __: TableColumn, cellValue: number) => {
      return h(
        ElTag,
        {
          type: cellValue === 1 ? 'success' : cellValue === 2 ? 'warning' : 'danger'
        },
        () => (cellValue === 1 ? '重要' : cellValue === 2 ? '派发' : '审核中')
      )
    }
  },
  {
    field: 'action',
    label: '操作'
  }
])

const actionFn = (data: TableSlotDefault) => {
  console.log(data)
}

const selectAllNone = () => {
  unref(elTableRef)?.toggleAllSelection()
}
</script>

<template>
  <ContentWrap title="表格">
    <ElButton @click="selectAllNone">全选/全不选</ElButton>
    <Table
      v-model:pageSize="tableObject.pageSize"
      v-model:currentPage="tableObject.currentPage"
      :columns="columns"
      :data="tableObject.tableList"
      :loading="tableObject.loading"
      :pagination="{
        total: tableObject.total
      }"
      @register="register"
    >
      <template #action="data">
        <ElButton type="primary" @click="actionFn(data as TableSlotDefault)"> 操作 </ElButton>
      </template>

      <template #expand="data">
        <div class="ml-30px">
          <div>标题：{{ data.row.title }}</div>
          <div>作者：{{ data.row.author }}</div>
          <div>创建时间：{{ data.row.display_time }}</div>
        </div>
      </template>
    </Table>
  </ContentWrap>
</template>
