import ThemeSwitch from './src/ThemeSwitch.vue'

export { ThemeSwitch }
