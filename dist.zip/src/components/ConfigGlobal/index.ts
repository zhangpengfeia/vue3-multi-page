import ConfigGlobal from './src/ConfigGlobal.vue'

export { ConfigGlobal }
