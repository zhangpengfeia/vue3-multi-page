import Authority from './src/Authority.vue'

export { Authority }
