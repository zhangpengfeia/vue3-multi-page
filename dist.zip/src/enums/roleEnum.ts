export enum RoleEnum {
  // super admin
  ADMIN = 'admin',
  // tester
  TEST = 'test'
}
